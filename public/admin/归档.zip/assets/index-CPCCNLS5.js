import{s as E}from"./antd-vendor-DaJANQRB.js";let o=0,r="";const a=1e3,i=(t,e=3)=>{const s=Date.now();(s-o>a||t!==r)&&(E.error(t,e),o=s,r=t)};export{i as s};
